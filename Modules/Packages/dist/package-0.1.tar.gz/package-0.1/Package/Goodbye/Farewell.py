# This is a module with functions that says good bye

def farewell():
    print("Good bye, I'm from the function greet from the module Farewell")

class Good_bye():
    def __init__(self) -> None:
        print("Good bye, I'm from the class Good_bye")