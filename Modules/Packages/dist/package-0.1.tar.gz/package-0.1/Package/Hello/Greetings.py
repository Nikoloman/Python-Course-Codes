# This is a module with functions that greets

def greeting():
    print("Hello There!, I'm from the function greet from the module Greetings")

class Greet():
    def __init__(self) -> None:
        print("Hello There!, I'm from the class Greet")