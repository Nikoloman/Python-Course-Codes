from setuptools import setup

setup(
    name="package",
    version="0.1",
    description="This is a package sample",
    author="Nikolo",
    author_email="hectorvel52@gmail.com",
    scripts=[],
    packages=["Package", "Package.Goodbye", "Package.Hello"]
)